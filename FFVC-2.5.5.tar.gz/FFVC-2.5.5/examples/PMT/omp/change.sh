#!/bin/sh

mv condition.txt condition_$1.txt
mv DomainInfo.txt DomainInfo_$1.txt
mv history_base.txt history_base_$1.txt
mv history_domainflux.txt history_domainflux_$1.txt
mv profiling.txt profiling_$1.txt
