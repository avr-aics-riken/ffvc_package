# FFV-C

## TODO


## Compiled

|Environment|Serial|MPI |Host|
|:--|:--:|:--:|:--|
|Intel / Intel 17.0.1 |x|ok(1)|Apple MacBook Pro 10.12.4|
|Intel / GNU 6.2.0    |x|ok(1)|Apple MacBook Pro 10.12.4|
|Fujitsu / fx10       |x|ok|Hayaka /opt/FJSVfxlang/1.2.1|


- (1) OpenMPI 1.10.4


## REVISION HISTORY

---
- 2018-11-27 Version 2.5.9
  - 乱流統計量、レイノルズ応力のみ計算するオプションを有効化
  - io_sph.f90を追加し、Reynolds_Stressディレクトリに直接出力
  - DFIの制御なし


---
- 2018-11-06 Version 2.5.8
  - AXBの係数書き出し


---
- 2018-09-27 Version 2.5.7
  - PAPIのリンク


---
- 2018-09-26 Version 2.5.6
  - checkOMPを陽に書く


---
- 2018-09-24 Version 2.5.5
  - PAPI support


---
- 2018-09-24 Version 2.5.4
  - CMP0012
  - CMAKE_INSTALL_SYSTEM_RUNTIME_LIBS_NO_WARNINGS TRUE
  - printCompoStatistics()でリスタート時のエラー発生のため、コメントアウト

---
- 2018-06-15 Version 2.5.3
  - intel_F_TCS
  - ISNAN => isnan()

---
- 2017-07-06 Version 2.5.2
  - set(CMAKE_FIND_ROOT_PATH /opt/FJSVtclang/1.2.0) in Toolchain_K.cmake


---
- 2017-04-22 Version 2.5.1
  - fix cmake install
  - fx10 compilation


---
- 2017-04-21 Version 2.5.0
  - Cmake version
  - serial version has a problem of ambiguous MPI_SUM to compile


---
- 2016-02-04 Version 2.4.4
  - r1639 update year 2016


---
- 2015-11-28 Version 2.4.3
  - r1638 bug fix in ab2 routine


---
- 2015-11-28 Version 2.4.2
  - r1637 --with-comp becomes essential
    - change configure.ac, INSTALL, and NEWS


---
- 2015-09-13 Version 2.4.1
  - r1636 suppress check print


---
- 2015-09-12 Version 2.4.0
  - r1635 bugfix: check duplication in loadBCs()

  - r1634 version 2.4.0
    - version 2.4.x => PMlib that corresponds to process group


---
- 2015-07-27 Version 2.3.15
  - r1633 introduce process group
  - r1632 update PMlib-4.0.1


---
- 2015-07-26 Version 2.3.14
  - r1631 merge the rest of pull request #23


---
- 2015-07-25 Version 2.3.13
  - r1630 merge pull request #23 manually and bug fix
    - update user guide : Output statistics


---
- 2015-07-25 Version 2.3.12
  - r1629 modify wall parameter
    - remove getWallType()
    - add /TurbulenceModeling/VelocityProfile
    - update included user guide


---
- 2015-07-25 Version 2.3.11
  - r1628 use MPIPolylib::load_only_in_rank0() and  distribute_only_from_rank0()
    - get accurate BC area


---
- 2015-07-15 Version 2.3.10
  - r1627 update examples for latest parameters
  - included examples; 2Dcavity, 3Dcavity, 2Dcyl, Jet, LDC, PMT


---
- 2015-07-10 Version 2.3.8
  - r1626 change parameter orgnization
    - /Output
    - LimitedCompresibility
    - Preconditioner


---
- 2015-07-10 Version 2.3.7
  - r1625 change mask from d_cdf to b_bcd
  - update_vec(), update_vec4_(), divergence_cc_(), pvec_central_(), pvec_central_les_()



---
- 2015-07-09 Version 2.3.6
  - modify bicg
  - add Limited compressibility
  - non-dim param for stability
  - modify Stability Control
  - add Stability Control function
  - gather isnan flag in Loop()


---
- 2015-07-05 Version 2.3.5
  - modify Vspec implementation
  - encVbitIBC(), encVbitIBCrev(), encVbitOBC()
  - expire VBC_UWD flag


---
- 2015-06-30 Version 2.3.4
  - suppress error message in mergeSameSolidCell()
  - expire paintCutOnPoint()


---
- 2015-06-29 Version 2.3.3
  - add mergeSameSolidCell()


---
- 2015-06-28 Version 2.3.2
  - add core_psor.h, core_sor2sma.h


---
- 2015-06-28 Version 2.3.1
  - add *cmp and *mat in Geometry class
  - brush up algorithms in Geometry


---
- 2015-06-21 Version 2.2.3
- introduce ffvc-config
- introduce dryrunBC()
- modify extractVelLBC() and related parts
- expire mask for residuals in psor_() and psor2sma_core_()


---
- 2015-06-19 Version 2.2.2
  - remove mask from blas_calc_rk_() and blas_calc_ax_() to make stable
  - rm VLD_CNVG >> active_bit
  - modify encPbit(), encPbitN(), norm_v_div_l2_(), norm_v_div_max_()
  - replacing if-branch to mask combination in psor_(), psor2sma_core_()
  - arrange Geometry.C
  - move onBit()/offBit() from VoxInfo.h to FB_Define.h
  - add special BC polynomial6 for chiba-u
  - modify quantizeCut()
  - add range for Glyph


---
- 2015-06-14 Version 2.2.1
  - error: MainLoop() C.Interval[Control::tg_End].printInfo("tg_End") destroys array


---
- 2015-06-10 Version 2.2.0
  - clean package


---
- 2015-06-09 Version 2.1.9
  - This fill algorithm can successfully generate a voxel model for Nasal2015 case.


---
- 2015-06-06 Version 2.1.8
  - Change to run configure
  - Change configure.ac
  - ducky, cavity, BMW_M3, nasal(0.2, 0.4mm)
  - enable fileout of bvx format
  - remove obsolete svx output


---
- 2015-06-01 Version 2.1.7
  - remove fill_bid.h


---
- 2015-03-01 Version 2.1.5
  - define ISNAN in FBdefine.h
  - update libraries
  - set dummy values for cmp[m].medium in case of Periodic
  - skip rading filepath for intrinsic problems
  - confirm detail later
  - reference point must be dimensional, partially it was non-dimensional


---
- 2015-02-25 Version 2.1.4
  - generate polylib.tp file from boundary section
  - modify fill medium


---
- 2015-02-17 Version 2.1.3
  - 2Dcavity, 3Dcavity, 2Dcyl, Cylinder, Jet, LDC, PMT, ThermalCavity, SHC1D
  - check Cylinder
  - check 2Dcavity, 3Dcavity, 2Dcyl, Cylinder, LDC, PMT, SHC1D ,Jet, HeatedPlate, ThermalCavity


---
- 2015-02-11 Version 2.1.2
  - introduction of fill hint


---
- 2015-02-11 Version 2.1.1
  - introduction of fill hint

---
- 2015-02-07 Version 2.1.0
  - insert mpi.h at first in ParseMat.h and CompoFraction.h
  - change calculation policy from ceil to round off to get g_voxel in SD_getParameter()


-----
- 2015-02-05 Version 2.0.9
  - add printForceAvr()




  --------------------------
  2015-02-01
  r1586 correction of CompoFraction class
  - pass non-dimensional parameter

  r1585 update test

  r1584 correct id management of IP_Cylinder
  - update parameter files for intrinsic examples
    >> 2Dcavity, 3Dcavity, 2Dcyl, Cylinder, LDC, PMT

  --------------------------
  2015-01-31
  r1583 bug fix in fill()
  - correction of pressure gradient : update_vec_()

  --------------------------
  2015-01-27
  r1582 Introduce flags for unisotropic Cartesian
  - expire naive implementation
  - expire facing_? flags and introduce bc_dn_? flags
  - divergence_cc => change calculation from sum_(u^*) to div(u^*)

  --------------------------
  2015-01-21
  r1581 bug fix in paintedCutOnPoint in Geometry.C

  r1580 modify cut index and related functions

  --------------------------
  2015-01-20
  r1579 expire polygon scaling, then Unit.Length is limited to "M" and "Non-dimensional"

  --------------------------
  2015-01-13
  r1578 Moller's algorithm for triangle-line intersection

  --------------------------
  2015-01-11
  r1577 flaging of long long int
  - modify methods in FB_Define.h related to long long flag
  - remove cutlib and replace functions in Geometry

  --------------------------
  2014-12-30
  r1576 branch compressed-cut, initial comit
  - d_cut : float >> long long
  - add fill_bit_naive.h
  - separate PolygonProperty class from Control.h

  --------------------------
  2014-12-25
  r1575 modify CellID, BCflag output

  r1574 modify SOLIDREV implementation

  --------------------------
  2014-12-21
  r1573 Introduction of BC for solid revolution SOLIDREV

  --------------------------
  2014-12-05
  r1572 header issue for BlockSaver.h

  --------------------------
  2014-12-04
  r1571 introduce bvx in FILEIO
  - output vbx file

  --------------------------
  2014-11-29
  r1570 ducky isothermal flow
   - calculate component's bbox

  r1569 ducky
   - bug fix : calulate the number of OBSTACLE in setBCIndexBase()

  --------------------------
  2014-11-23
  r1568 Introduce boundary conditions for Central scheme
   - pvec_ibc_specv_fdm_(), vobc_pv_specv_fdm_()
   - guide=2 is required for all cases owing to the implementation of traction free BC
   - vobc_cc_tfree_(), vobc_cf_tfree_()
   - Introduce Geometry class
   - move findIDfromLabel() from Control to FBUtility
   - move variables related fill function from Control to Geometry
   - move fill functions from VoxInfo to Geometry

  --------------------------
  2014-11-17
  r1567 remove unrecognized charcters in History.C

  --------------------------
  2014-11-16
  r1566 output summary for averaged force of components
   - split rms and rmsmean to rmsV, rmsmeanV, rmsP, rmsmeanP, rmsT, rmsmeanT
   - change trigger of statistic from LES.calc to Mode.StatVelocity
   - check the number of cylinders in IP_Cylinder
   - write a separate force file for each obstacle

  --------------------------
  2014-11-14
  r1565 arrangement ffv_blas.f90

  --------------------------
  2014-11-13
  r1564 bug fix : restart statistic and cast pointer to fortran subroutine
   - Control::getTimeControl()
   - modify cast to fortran subroutine in ffv_Loop.C
   - add InnerIteration of BiCGstab

  --------------------------
  2014-11-09
  r1563 improve calcForce()

  r1562 improve PBiCGstab
   - suppress initialization of arrays in PBiCGstab

  r1651 modify for PMlib-3.0.0
   - improve PBiCGstab algorithm
   - chnage policy of 2D limitation when 2D must be 1 layer in Z-direction (3 layers in the past)

  --------------------------
  2014-11-06
  r1650 outflow condition modify
   - vobc_cc_outflow_() exclude cell of OBC_MASK
   - sph derived >> fix

  --------------------------
  2014-11-05
  r1649 CDMlib plot3d restart ok
   - improve plot3d format in CDMlib-0.5.3
   - d_iobuf was examined
   - confirm restart by plot3d format

  --------------------------
  2014-11-01
  r1648 CDMlib plot3d restart
   - extract_scalar()/_vector()
   - pack_to_buffer_(), unapck_from_buffer_()


  --------------------------
  2014-11-01
  r1647 CDMlib plot3d branch test
   - XYZ file, Iblank option
   - Control::GuideOut >> change input from "with/without" to the number


  --------------------------
  2014-10-31
  r1646 Experiment 4th div error
   - PointSOR_4th(), src_1st_(), src_2nd(), src_trunc_()
   - Currently, it does not give good result.

  --------------------------
  2014-10-31
  r1645 update LES
   - update_vec4_(), pvec_muscl_les_(), pvec_cental_les_(), calc_rms_v_(), perturb_u_?_()
   - Average >> Statistic


  --------------------------
  2014-10-25
  r1644 fix a minor bug of r1643
   - compatible with CDMlib-0.4.0

  --------------------------
  2014-10-24
  r1643 change memory allocation structure
   - introduce ffv_Alloc.C/h
   - modify for CDMlib-0.3.1
   - change input format for /Output/Data/Format
   - merge DerivedVariables with BasicVariables
   - Measures of GNU Compile error dyanmic_cast<IterationCtl*>(LS)

  --------------------------
  2014-10-23
  r1642 introduce FILE_IO
   - IO_BASE class
   - remove ffv_Restart.C
   - SPH class

  --------------------------
  2014-10-19
  r1641 Graph ploter function
   - still ther are issues in getMonitor()
   - expire printHistoryItr()
   - move output of divergence to derived variables

  r1640 master trunk
   - remove src/PLOT3D src/Util_Layout

  --------------------------
  2014-10-18
  r1639 change CIOlib to CDMlib

  Merge to main trunk

  r1638 branch change-itr cleanup
   - clean test functions

  r1637 branch change-itr HSMAC
   - test HSMAC
   - redesign Iteration class

  --------------------------
  2014-10-02
  r1636 branch change-itr BiCG naive
   - Naive implementation of BiCGstab
   - Introduce F_LS directory for Linear Solver

  --------------------------
  2014-09-28
  r1635 branch change-itr
   - Test standard Projection method
   - Expire v_div_? for Norm_Type
   - /ApplicationControl/DebugDivergence in tp file -> /Output/Log/Iteration
   - change interface of NormDiv()
   - change IterationCtl class > Residual and Error
   - expire bit3option
   - Modify iteration process

  --------------------------
  2014-09-22
  r1634 Implementation of Cd/Cl
   - modify copyBCIbase()
   - add variables in ffv.h
     cmp_force_local, cmp_force_global, buffer_force, global_obstacle, num_obstacle
   - impliment calcforce(), gatherForce(), force_compo_()
   - modify printHistoryForce()
   - add variable matodr in Component.h

  --------------------------
  2014-09-16
  r1633 estimate viscous terms as 4th-order
    - change implementation of pvec_central()
    - bug fix both 2nd and 4th central schemes

  --------------------------
  2014-09-06
  r1632 bug fix in PobcPeriodicDirectional()
    - fix index in X_minus direction

  --------------------------
  2014-08-30
  r1631 bug fix of Periodic condistion

  r1630 modify the implementation of the convection part
   - add O4_Central scheme
   - remove getConvection()
   - expand load_var_stencil5.h into source codes and remove it to avoid including a file twice
   - expand d_o_o_p.h into source codes and remove it
   - expand muscl.h into source codes and remove it
   - refine pvec_muscl
   - change icpc compiler option because the current options will be deprecated
       -vec-report=3 -par-report=3 >> -qopt-report=5

  --------------------------
  2014-08-27
  r1629 bug fix double precision compilation
   - search_polygons(..REAL_TYPE,..) in ASDmodule.C
   - init_parallel_info(..REAL_TYPE,..) in ASDmodule.C
   - remove FileIO class and related f90 routines
   - move FB_util.f90 to F_CORE/ directory

  --------------------------
  2014-08-26
  r1628 modify ASD/SubDomain.C too
   - modify ASD/SubDomain.C writeSVX(const string& path, const float* pch, const REAL_TYPE* org)

  r1627 modify ASD/SubDomain.h
   - bool writeSVX(const string& path, const float* pch, const REAL_TYPE* org) << const float* org

  --------------------------
  2014-08-24
  r1626 modify Bbox calculation for components

  r1625 bugfix restart by time
   - getTimeControl() >> add /TimeControl/Session/RestartStep in order to detemine the accurate restart step when By_time is specified.

  --------------------------
  2014-08-01
  r1624 update IP_Cylinder class [ver 1.8.1]
   - new functions in ffv_Geometry.C
     >> SeedFilling(), findPolygonInCell(), calcBboxFromPolygonGroup()
     >> SubSampling()
   - introduce d_pvf to represent a volume fraction owing to polygons
   - remove message() from FB_Define.h to avoid confliction with func. in <locale>
   - Change algorithm of find_mode_id() & find_mode()

  --------------------------
  2014-04-24
  r1623  [ver 1.8.0]
   - bug fix of index calculation in MonitorCompo::setPrimitive()
   - change type of floating-point from Vec3d to Vec3r >> Monitor & CompoFraction

  --------------------------
  2014-04-16
  r1622 Bug fix of restart for dimensional case [ver 1.7.9]
   - deltaT -> (deltaT*C.Tscale) in RestartInstantaneous() and RestartAvrerage()

  --------------------------
  2014-04-03
  r1621 double mtbl [ver 1.7.8]
   - assign double to mtbl
   - change interface e.g., convArrayIE2Tmp()

  --------------------------
  2014-04-02
  r1620 update restart by time [ver 1.7.7]
   - modify initInterval()
   - expire nGroup in MonitorList class, instead use monGroup.size()

  --------------------------
  2014-03-23
  r1619 update sampling [ver 1.7.6]
    - remove Vec3.h from FB >> already included by Polylib
    - move interpolation methods in basic_func.h to Smapling.h
    - set type of floating-point to double in sampling procedure

  --------------------------
  2014-03-22
  r1618 update division pattern cube/comm [ver 1.7.5]

  --------------------------
  2014-03-19
  r1617 add include file [ver 1.7.4]
    - add stdio.h in Sampling.h
    - add string.h in SubDomain.h

  --------------------------
  2014-03-18
  r1616 change filename Vec3.h from vec3.h [ver 1.7.3]

  --------------------------
  2014-03-17
  r1615 commn namespace Vec3class [ver 1.7.2]

  --------------------------
  2014-03-16
  r1614 bug fix : restart by time [ver 1.7.1]

  r1613 Automatic decision of subdomain division [ver 1.7.0]
    - source refers CPMlib and FXgen
    - bug fix : pitch check in getDomainParameter()
    - change abnormal termination >> isnan()

  --------------------------
  2014-03-11
  r1612 bug fix : change link order [ver 1.6.9]

  --------------------------
  2014-03-10
  r1611 introduce Active subdomain module [ver 1.6.8]
    - change Make structure, main.C is placed just under src/

  --------------------------
  2014-03-09
  r1610 modify heat source bc [ver 1.6.7]

  r1609 bug fix outer IsoThermal BC [ver 1.6.6]
    - modify setBCindexH(), encAdiabatic() to flip adiabatic bit
    - modify output form fo History_Domainflux >> Q and H only
    - add ThermalCavity in examples

  --------------------------
  2014-03-08
  r1608 modify ver 1.6.5

  r1607 Filter module [ver 1.6.5]
    - introduce EXEC_MODE to identify mode (solver|filter)
    - ffv_Filter.C

  --------------------------
  2014-03-04
  r1606 conjugate heat transfer [ver 1.6.4]

  r1605 fix bug related r1604 and improve fill [ver 1.6.3]
    - modify fill_bid.h
    - add paintCutIDonGC (int* bcd, const int* bid)
    - expire bin-script, ffvc-config

  --------------------------
  2014-02-27
  r1604 suppreess fill direction [ver 1.6.2]
    - modify trap in loadOuterBC() : if ( i == NoBaseBC )
    - modify IP_Step::setup()
    - move Fill related paramete from getApplicationControl() to getGeometryModel()
    - introduce connectivity suppression in fill_bid for periodic and symmetric

  --------------------------
  2014-02-19
  r1603 Change implementation of symmetric condition to flux type [ver 1.6.1]
    - remove vobc_symmetric_()

  --------------------------
  2014-02-11
  r1602 NERSC Hopper [ver 1.6.0]
    - add CCcompiler wrapper in configure.ac

  --------------------------
  2014-02-09
  r1601  [ver 1.5.9]
   - move Bit3option form ApplicationControl to Iteration/LinearSolver[@]
   - CIOlib-1.5.2 compatible

  --------------------------
  2014-02-08
  r1060 add configure for gfortran [ver 1.5.8]
   - change AC_PREREQ([2.69]) to 2.63 for convenience
   - from --with-comp=(INTEL|FJ) to --with-comp=(INTEL|FJ|GNU)
   - add FREALOPT="-fdefault-real-8", but not confirm yet
   - Currently gnu f2c can't translate f90 code perfectly, so modify long line to short in ffv_velocity_binary.f90
   - CIOlib 1.5.1 compatible

  --------------------------
  2014-01-23
  r1059 modify psor2sma_core_bit3_()

  --------------------------
  2014-01-21

  r1058 Test of enhanced implementation bit3 for Sparc architecture [ver 1.5.7]
   - poi_rhs_bit3_(), poi_residual_bit3_(), psor2sma_core_bit3_()
   - Control:: int Bit3option, getApplicationControl()
   - NS_FS_E_Binary.C -> if(C.Hide.Bit3option==OFF)...

  --------------------------
  2014-01-19

  r1057 introduce hint of fillseed for both fluid and solid [ver 1.5.6]
   - /ApplicationControl/HintOfFillingFluid >> /ApplicationControl/HintOfFillSeedDirection
   - add /ApplicationControl/HintOfFillSeedMedium
   - rename int FillHint -> int FillSeedDir
   - add int FillSeedMedium, int RefSeedMedium
   - check Cutlib-3.2.0 on Mac

  --------------------------
  2014-01-13

  r1056 change the keyword of 'FluidDirection' to 'InOut'

  --------------------------
  2014-01-03

  r1055 change include files for RHEL [ver 1.5.5]

  r1054 Naive Implementation for SOR2SMA [ver 1.5.4]
   - renew the expression of year in copuright from 2013 to 2014
   - Default of FillHint is set to X_minus in getApplicationControl()
   - add naiveImplementation option for SOR2SMA for experiment
   - move some methods related iteration parameter in Control class to IterationCtl class

  --------------------------
  2013-12-29

  r1053 bug fix [ver 1.5.3]
   - Monitor & Sampling related issue #1

  --------------------------
  2013-12-23

  r1052 bug fix & check [ver 1.5.2]
   - add ParseBC::loadLocalBCfromPolylibFile()
   - bug fix : issue #1 & #5 on github
   - read SPEC_VEL parameters in case of thermal flow

  --------------------------
  2013-12-05

  r1051 bug fix [ver 1.5.1]
   - incorrect calculation end was set

  --------------------------
  2013-11-23

  r1050 Introduction of Glyph
    - add /GeometryModel/OutputGlyph
    - add FB/Glyph.cpp, Glyph.h

  --------------------------
  2013-11-13

  r1049 bug fix: add Hostonly_ for minDistance()
    - In case of Polygon loading, MPI process yields seg. fault.

  r1048 output scaled polygon in the case of Unit.Length={mm, cm} [ver 1.5.0]
    - Modify setupPolygon2CutInfo() to load polygons in the case of Unit.Length is cm or mm.
    - expire INACTIVE mode and related methods > flip_inactive()
    - modify VLD_CNVG flag encoding in encPbitN()

  --------------------------
  2013-11-03

  r1047 bugfix: [ver 1.4.9]
    - initial temperature setting
    - log base off >> write file to unopened file pointer

  --------------------------
  2013-11-02

  r1046 compile on K/FX
    - clean package
  --------------------------
  2013-10-30

  r1045 compile on K/FX [ver 1.4.8]
    - update examples/SHC1D/shc1d.tp, examples/HeatedPlate/hplate.tp
    - FillHint is mandatory

  --------------------------
  2013-10-27

  r1044 Hall filling update [ver 1.4.7]

  r1043 Helicity sampling

  --------------------------
  2013-10-25

  r1042 Polygon Monitor

  r1041 change Monitor implementation
    - remove CELL_MONITOR
    - sampling line & points are reasonable, but polygon & primitive is not
    - component is not detected (bug)

  --------------------------
  2013-10-22

  r1040 Boundary ID based implementation
    - change algorithm from d_mid based to d_bcd based
    - delete d_mid related methods

  --------------------------
  2013-10-15

  r1039 substitute dfi file name
    - remove string variables of dfi file name and substituted by the refix of output file

  --------------------------
  2013-10-12

  r1038 bug fix for average restart

  r1037 repalce IntervalManager.h from CIOlib [ver 1.4.6]
    - change integer type from int to unsigned int in IntervalManager
    - add getLastStep(), getLastTime() in IntervalManager
    - integrate isLastStep() and isLastTime() to isLast() and cahnge to public method
    - rewrite timing control by a new IntervalManager

  --------------------------
  2013-10-11

  r1036 change keyword from 'Normal' to 'OrientationVector'

  r1035 update for CIOlib-1.3.8 [ver 1.4.5]
    - move dfiinfo.h from FB/ to PLOT3D/
    - delete extra methods in ffv_Restart.C
    - update for CIOlib-1.3.8

  --------------------------
  2013-10-06

  r1034 modify Algorithm for Binary [ver 1.4.4]
    - Replace cell face mask by Neumann flag >> pvec_muscl_(), update_vec_(), divergence_()
    - modify encPbitIBC(), encPbit_N() so that these methods use boundary ID information.
    - remove InnerVBC(), vibc_drchlt_(), vibc_outflow_(), assignVelocity(), assignTemp() due to change algorithm

  --------------------------
  2013-10-05

  r1033 exclude PLOT3D output [ver 1.4.3]
    - MPIinit is called at firstline in main.C because Intel MPI tells error message
    - PLOT3D functions are expired and will be supported by a new converter
    - dfi.h/C is replaced by CIOlib
    - temporally excludes compilation of PLOT3D and Util_Layout
    - combsph supports sph and avs

  --------------------------
  2013-10-03

  r1032 modify for intel MPI [ver 1.4.2]
    - include mpi.h before stdio.h to suppress error message #error "SEEK_SET is #defined but must not be for the C++ binding of MPI"
    - remove __ARCH_BG
    - add va_start to AC_CHECK_FUNCS([])

  --------------------------
  2013-10-01

  r1031 expire SolidFromCut() [ver 1.4.1]
    - getDomainParameter()で分割数の整合性チェックをROUND_EPSで判定
    - p_specific_heatの指定間違いを修正 >> ffv_SetBC.C
    - setBCinfo()でコンポーネントの指定温度を初期温度にコピー
    - SolidFromCut()でバイナリボクセルは作成しない >> 形状が変化する可能性有り
    - HeatedPlateをexampleに追加

  --------------------------
  2013-09-29

  r1030 update to CIOlib-1.3.6 [ver 1.4.0]
    - CIOlib-1.3.6への対応
    - Util_Combsphの修正

  --------------------------
  2013-09-23

  r1029 modify obtaining DFI_div
    - displayCutInfo() 交点情報のデバッグライト
    - I2VGTのファイル名プリフィクスを i2vgt -> qcr
    - selectRestartMode()のDFI_divの取得 >> KOS依存の分岐を追加

  r1028 Refactoring of FileIO
    - ベクトルデータのロード修正
    - 温度の読み込み変換
    - FileIO classのreadPressure/Velocity/TemperatureをCIOlibで置換 >> 削除
    - 温度の単位指定CIO::AddUnit()が不整合
    - CIOlib-3.1.5対応
    - Face Velocityの出力

  --------------------------
  2013-09-22

  r1027 recover PLOT3D format [ver 1.3.9]
    - PLOT3D関連メソッドを復活


  --------------------------
  2013-09-18

  r1026 FluidDirection
    - CCNV file出力オプション追加
    - FluidDirectionのパラメータ変更
    - GeomOutput

  --------------------------
  2013-09-13

  r1025 Celsius [ver 1.3.8]
    - 温度単位をCelsiusのみに統一，Unit/Temperatureを削除
    - 温度の変換ルーチンを整理
    - 代表量を整理 Control::setParameters() >> setRefParameters() + setCmpParameters()
    - FButilityの圧力，温度の変換についてscaleを削除
    - FB_util.f90の速度変換について，scaleを削除
    - mat_tblを無次元化，関連メソッドで次元変換
    - xcopy(), xset()をscalr/vector用に整数インデクスで記述 > copyS3D(), copyV3D(), initScalar()
    - 収録例題のパラメータをアップデート

  --------------------------
  2013-09-08

  r1024 merge
    - conjugateHT ブランチをメイントランクへマージ

  r1023 conjugate heat transfer SHC1D [ver 1.3.7]
    - 温度から内部エネルギーに変換　convertTmp2IE(), convertIE2Tmp()
    - 熱伝達境界条件を整理
    - 多媒質温度計産のため，温度から内部エネルギーの基礎式に変更
    - Fortranでの多媒質対応ルーチンのため，rho, cp, lambdaの配列を作成 >> mat_tbl[]
    - d_qbc[ix*jx*kx*3] >> d_qbc[ix*jx*kx*6]へ変更
    - ps_Diff_SM_PSOR()のd_qbc[]へのアクセスは _F_IDX_V3DEX >> _F_IDX_S4DEX
    - d_bh1をd_bcvに統合し，d_cdfに名称変更
    - SPEC_VEL_WHを削除
    - d_bh2 を d_bcdに統合

  --------------------------
  2013-09-03

  r1022 change area calculation
    - コンポーネントの面積は 要素数 x 面素 >> encodeBCindex()に追加
    - calCompoArea(), projectCompo()削除

  r1021 approximate component area [ver 1.3.6]
    - setGlobalCompoIdx_displayInfo()でグローバルなbboxから近似的な法線と面積を求める
    - calCompoArea(), projectCompo()追加
    - サブドメイン毎に配分されたポリゴンを出力するオプションを追加 C.Hide.GeomOutput

  --------------------------
  2013-09-02

  r1020 change from isCDS() to isBinary()
    - isCDS() >> isBinary()に変更
    - fillSeed()で固体面に隣接するセルでもシード点の対象とする
    - Intrisic::setup()にfloat* cutを追加．バイナリでもカット情報を用いる方針にする
    - setOBCcut()は壁面のみ，対称条件は外す，bidへのエンコードも行う
    - ffv_SetBC内で局所境界条件をBinary/Cutで同一にする

  --------------------------
  2013-09-01

  r1019 backstep
    - vobc_drchltのバグ修正
    - Backstep(ColdFlow)
    - 温度計算の場合の媒質毎の初期値指定オプション getInitTempOfMedium()

  --------------------------
  2013-08-31

  r1018 improve fill algorithm [ver 1.3.5]
    - /Referece/Mediumのエラーメッセージ変更
    - ポリゴンモデルを用いる場合に局所境界条件数が少なくとも一つあることを検査
    - fill()で固体IDを求めるアルゴリズムを修正
    - fillプロセスの修正
    - fill関連のセルカウントをunsigned longへ変更
    - openmpのfirstprivate化のためにワークリストの配列を[64]固定に変更

  --------------------------
  2013-08-30

  r1017 modify OuterBC policy
    - OuterBCの実装ポリシーを変更．周期境界は全ランクが参加する必要があるので，事前に非外部BCランクを排除しない
    - 各ランクのbc[]には同じ値を保持

  --------------------------
  2013-08-29

  r1016 change fileout timing of cellmonitor
    - セルモニターのファイル出力のタイミングを tg_sampled から tg_history へ変更

  --------------------------
  2013-08-24

  r1015 bugfix print outer BC
    - OuterBCの表示が不正であったバグを修正
    - SHC1Dをexampleに収録
    - 2Dcavity, Cabity_Binary, LDC, Jet, PMT, Sphere の入力ファイルをアップデート
    - OuterTBCface()で熱量収支のallreduceを行う方針（従来は，個別のメソッド内で実施．冒頭に書いた領域内のときのreturnでデッドロックになるバグ）
    - ConvergenceMonitorを導入し，流動と熱の定常状態をモニター

  --------------------------
  2013-08-22

  r1014 update ffvc_ug.pdf ver 0.8.0

  r1013 modify parameter structure [ver 1.3.4]
    - パラメータの構成変更 >> ApplicationControl

  --------------------------
  2013-08-19

  r1012 Filling Medium [ver 1.3.3]
    - Reference medium と Filling mediumを分ける
    - step/timeの指定をTempralTypeで統一
    - SHC1Dクラスを組み込み例題から削除．ポリゴン版で対応．結果の確認
    - ParseBC::getCmpGbbox_ed()のバグ修正
    - コンポーネントモニタのファイル出力は/MonitorListで制御

  --------------------------
  2013-08-14

  r1011 modify behavior of restart
    - リスタート時の挙動を修正

  --------------------------
  2013-08-13

  r1010 remove TPControl class [ver 1.3.2]
    - TPControlクラスを追加したTextParser-1.4.0に対応 >> TPControl.h/Cは削除

  --------------------------
  2013-08-12

  r1009 change parameter structure [ver 1.3.1]
    - /BCTable/OuterBoundary/FaceBC/Xminus/MediumOnGuideCell  >>  /BCTable/OuterBoundary/BasicBCs[@]/MediumOnGuideCell
    - /Steer/GeometryModel/HintOfFillingFluid  >>  /DomainInfo/HintOfFillingFluid
    - /Iterationのパラメータセットを変更
    - /Steer, /Parameterをとる．パラメータをトップの直下に変更．
    - /Steer/SolverProperty >> /GoverningEquation
    - IterationCtl + ConvergenceCriterion >> IterationCtl class, IterationControl.h
    - ラベル配列はlist[@]とIteration
    - 外部境界面の判断を BoundaryOuter::dataCopy()において，BCclassへの境界条件番号に変更 OFF(0)のとき内部面

  --------------------------
  2013-08-02

  r1008 Change implementation of outer boundary routine
    - TractionFreeの再実装
    - 外部境界処理サブルーチンに隣接ランク番号を渡し，サブルーチン内で実行選択を行う．
    　外部境界条件処理手続きで同期が必要な場合，全てのランクが参加する必要があるための対応

  --------------------------
  2013-08-01

  r1007 bug fix of dynamic allocation
    - プロセス並列時にhistory_compo.txtのVspecモニタ値がゼロになるバグを修正（existLocal()の副作用）
    - コンポーネントがサブドメインに存在しない場合には，bboxの値をゼロにする >> DomainInfo.txtで確認
    - 並列時のsetGlobalCmpIdx()のインデクス計算を修正（表示用）
    - 動的配列への変更

  --------------------------
  2013-07-28

  r1006 Introduce ffv_Version.h
    - バージョン番号の自動生成
    - 分割時の丸め誤差に起因するエラーの対応 >> 自動分割処理
    - Intrinsic example : stokes2nd
    - 内部フィルを実行する場合の固体IDを計算する関数
      int VoxInfo::getFillSolidID(const int* mid)
    - ノルムのゼロ割対応
    - count_comm_size()内のallreduceが性能上の問題となっていた（何かの作業でのミス）ものを除去
    - BCのsetEnsLocal()の処理 >> Heat関連は未処理

  --------------------------
  2013-07-27

  r1005 polygon problem
    - FXgenからのパラメータの流れを整理
    - NoMedium, NoBC, NoCompo > cmp[], mat[]の配列の大きさはNoCompoで統一
    - Libraryのバージョン番号を表示
    - 媒質テーブルのロードを変更
    - setMonitorCellID()の追加
    - VoxScan(), scalCell()のアルゴリズム変更
    - BCindexの不要部分抑制 MediumとMatOdrは同じに，CellIDは不要
    - セルモニターの幅を指定

  --------------------------
  2013-07-16

  r1004 configure.ac for non-intel compiler
    - Intelコンパイラ固有のオプション制御 ifport ifcore

  r1003 modify fill for solid-cut only
    - comment out: Solid_from_Cut(int* mid, ..., const int target)
    - Solid cutのみを対象とする > fill_by_mid(), fill_seed(), fill_by_bid(),
                               Solid_from_Cut(int* mid, …, CompoList* cmp)
    - /BCtable/LocalBoundary/BC[@]/samplingMode, samplingMethod

  --------------------------
  2013-07-15

  r1002 add calcBboxfromPolygonGroup()
    - CompoFraction::get_min/maxをstaticに変更
    - PolygonProperty::min, maxとsetter/getterを追加
    - calcBboxfromPolygonGroup()を追加

  r1001 BC recognition by cut info
    - FFV::setup_Polygon2CutInfo(), FFV::min_distance()の整理
    - Cutの最小値計算時間の比較 CutPos->getPos()よりインデクスの直接計算の方が高速
    - PorygonPropertyクラスによりポリゴンの情報管理(Control.h)
    - encVBC_Cut()の修正，テスト中

  --------------------------
  2013-07-13

  r1000 confirm operation /w Polylib-2.6.4 and Cutlib-3.1.2 [ver 1.2.4]
   - modify configure.ac for GNU fortran /w openMPI 1.6 or later
   - change poly_org/poly_dx from double to float, and add cut_org/cut_dx
   - Polylib and Cutlib check for binary voxel

  --------------------------
  2013-07-11

  r999 extend min/max calculation [ver 1.2.3]
   - fb_minmax_v(), fb_minmax_vex()

  r998 keyword error trap in MediumTable [ver 1.2.2]

  r997 change parameter format
   - BCTable/FaceBC/Xminus/Alias  ->  AssignedAlias
   - Change parameter structure of Iteration
   - Add ConveregenceCriterion class in Control.h
   - Control::findCriteria() -> Control::setCriteria()
   - Add Control::setPara_*() for iterative methods
   - change /Meidum/label -> alias
   - Density -> MassDensity

  --------------------------
  2013-07-10

  r996 change order of link in Makefile.am
   - before) @CPM_LDFLAGS@ ... @FFVC_FC_LD@ -L../FB -lFB -L../IP -lIP …
   - after) -L../FB -lFB -L../IP -lIP … @CPM_LDFLAGS@ ... @FFVC_FC_LD@

  --------------------------
  2013-07-07

  r995 change package name from ffvc to FFVC

  --------------------------
  2013-07-06

  r994 make package 1.2.0

  ----------------------------
  2013-07-05

  r993 autotool trying

  r992 Compile OK by Makefile_hand

  r991 modify Makefile_hand to suppress depend target for f90
   - Makefile_handでf90ターゲットのdependを抑制

  r990 modify for CIOlib 1.3.x
   - CIOlib 1.3.x以降への対応
       FB/dbwrite.f90の追加
       ffv.C  CIOlib debug
       ffv_Initializa.C dfiクラスの代替
       ffv_REstart.C 解像度が2倍のチェック

  r989 modify srcs by ffvc-mini app's comment
   - ffvc-mini app.の整備過程で発見した修正
       NS_FS_E_Binary.C
   - res_initがsqrtされていない
       未初期化のconvergence_prevを参照
       ffv_velocity_binary.f90
         pvec_musclで、FIRSTPRIVATEに指定しているdhがdoループ内で未使用
         (Intelコンパイラで-O0で実行するとセグメント違反で落ちる)
       ffv_LS.C
         tm_poi_src_nrmのflop_countに，直前の最後のPoisson反復でのtm_poi_SOR2SMA
         のfloop_countが混入

  ----------------------------
  Date:    Jul 4 18:17:38 2013

  r988 Cutlib-3.1.1
   - Cutlib-3.1.1対応のため，GridAccessorクラスを用いたインターフェイスに変更
   - setup_Polygon2CutInfo()でpoly_org, poly_dxをdoubleへ変更

  ----------------------------
  Date:    Jul 3 23:06:08 2013

  r987 update copyright for all source

  r986 change makefiles

  r985 packaging adjustment
   - パッケージ形式をautotoolsを利用したインストールに合わせて変更開始

  ----------------------------
  Date:    Jun 22 15:35:54 2013

  r984 move doc.tex to doc.git

  r983 add README.md

  ----------------------------
  Date:    Jun 15 16:39:52 2013

  r982 correct release note

  r981 correct revision number

  r980 PMlib is handled as outside library

  ----------------------------
  Date:    Jun 13 12:00:23 2013

  r979 change Makefile of Polylib cpp  > cpp

  ----------------------------
  Date:    Jun 12 10:52:55 2013

  r978 add License files

  r977 restart mode fixed

  ----------------------------
  Date:    Jun 11 23:49:04 2013

  r976 compiled

  r975 restart mode change

  r974 check

  r973 working

  r972 link-off dfi.C dfiinfo.C and PLOT3D class

  ----------------------------
  Date:    Jun 10 18:48:51 2013

  r971 compile & run

  r970 fix comment

  ----------------------------
  Date:    Jun 8 17:52:49 2013

  r969 CIOlib-1.1 compiled
   - CIOlibを外部ライブラリとしてリンク, CIOlib-1.1をテスト実装

  r968 CIOlib-1.1 & modify from r963 by FE, but ambigious
   - CIOlib導入による修正
       リスタート関連のメソッドをコメントアウト ffv_Restart.C
       DFIはCIOlibでハンドリングしているので，既存のDFIクラスをインクルードから外す
       Plot3Dクラスはメンテできていないのでコメントアウト　20130611のラベル
       MakefileからもPLOT3D関連のビルドを外す > UDEF_LIBSからPLT3Dへのリンクを外すだけ
       DFI_OUT_DIVを追加

  r967 Modify division policy again
   - 分割ポリシーのバグ修正

  r966 Modify division policy

  ----------------------------
  Date:    Jun 6 08:24:33 2013

  r965 check >> Both global voxel and pitch...

  ----------------------------
  Date:    Jun 3 23:00:55 2013

  r964 Jet dimension

  ----------------------------
  Date:    May 14 18:10:35 2013

  r963 PPLT2D

  ----------------------------
  Date:    May 9 09:23:20 2013

  r962 Makefile modify

  ----------------------------
  Date:    May 8 20:43:25 2013

  r961 Polylib-2.4

  r960 CIO Lisence

  r959 PMlib-1.7 kai & CIOlib update

  r958 PMlib-1.7

  r957 fix restart interval
   - リスタート時のインターバル不正のバグ修正

  ----------------------------
  Date:    Apr 30 11:36:27 2013

  r956 PMlib

  ----------------------------
  Date:    Apr 26 04:53:37 2013

  r955 double C.Tscale
   - C.Tscale, time周りをdoubleに修正

  ----------------------------
  Date:    Apr 15 12:19:32 2013

  r954 CIOlib

  ----------------------------
  Date:    Apr 13 16:49:16 2013

  r953 working

  r952 compile ok includs CIOlib

  r951 pmlib1.6+

  r950 pmlib1.6

  r949 PMlib-1.6

  r948 CIOlib working
   - CIOlib導入

  ----------------------------
  Date:    Apr 5 14:25:58 2013

  r947 FaceVel
   - FaceVelocity出力をオプションに変更

  ----------------------------
  Date:    Apr 4 18:24:13 2013

  r946 working

  ----------------------------
  Date:    Apr 2 18:33:10 2013

  r945 vbc

  r944 vobc_gc
   - vobc_face_drchletの配列領域侵害のバグを修正

  r943 Jet

  ----------------------------
  Date:    Apr 1 18:34:32 2013

  r942 new outflow & farfield
   - OBC_FAR_FIELDを値指定のノイマン条件実装に変更
   - OBC_SYMMETRICを値指定実装

  r941 outflow change
   - OBC_OUTFLOWを値指定方式に変更

  r940 jet

  r939 fix periodic
   - 周期境界のバグ修正

  ----------------------------
  Date:    Mar 31 22:49:55 2013

  r938 prdc

  r937 beautify

  r936 modify intrinsic

  r935 init mod

  ----------------------------
  Date:    Mar 28 00:51:13 2013

  r934 pmlib label

  ----------------------------
  Date:    Mar 26 23:41:09 2013

  r933 Polylib-2.3 ref2

  r932 Polylib-2.3 rev

  r931 Polylib-2.3
   - Polylib 2.3 対応

  r930 domain itor jet

  ----------------------------
  Date:    Mar 25 19:47:57 2013

  r929 farfield
   - OBC_FAR_FIELDのノイマン条件実装

  r928 modify division policy
   - 領域分割時　G_Region = G_Voxel * G_Pitch でない場合のバグを修正 (get_DomainInfo)
     分割のポリシー
     G_regionは必須
     G_voxelとG_pitchでは，G_voxelが優先．
     両方が指定されている場合には，エラー
     G_pitchが指定されている場合には，割り切れない場合，
     G_voxel = (int)ceil(G_region/G_pitch)
     G_region = G_pitch * G_voxel

  ----------------------------
  Date:    Mar 24 23:15:59 2013

  r927 tfree modify
   - OBC_TRC_FREE再実装

  r926 dirichlet p

  r925 outflow

  ----------------------------
  Date:    Mar 23 17:34:25 2013

  r924 bc modify

  - rr923 jet 1

  ----------------------------
  Date:    Mar 20 17:58:54 2013

  r921 jetbc

  r920 jet

  ----------------------------
  Date:    Mar 18 22:50:38 2013

  r920 working
   - /Steer/FIleIO/IOmode >> distributed is default

  r919 jet-bit

  ----------------------------
  Date:    Mar 17 16:36:30 2013

  r918 jet vbc

  ----------------------------
  Date:    Mar 16 17:51:51 2013

  r917 modify vbc

  r916 modify domainitor
   - 初期化ルーチン再構築 >> setupDomain()

  r915 jetbc 2

  ----------------------------
  Date:    Mar 10 17:19:49 2013

  r914 jet bc working

  r913 jet bc

  ----------------------------
  Date:    Mar 6 17:14:00 2013

  r912 jet

  ----------------------------
  Date:    Feb 17 17:44:19 2013

  r911 hierarchical directory createion

  r910 update tp files

  r909 plot3d refine
   - PLOT3D出力の様式変更への対応 >> ffv_Initialize.C, ffv_Loop.C

  ----------------------------
  Date:    Feb 16 18:18:13 2013

  r908 working

  ----------------------------
  Date:    Jan 29 08:59:10 2013

  r907 working
   - 外部境界条件で部分的に流速を与える（ガイドセルに固体IDを入れておきマスクする）
     vobc_pv_specv_(), vobc_div_drchlt_()

  ----------------------------
  Date:    Jan 26 17:39:16 2013

  r906 Jet working

  r905 signal handler
   - シグナルイベントハンドラを実装 FFV_TerminateCtrlクラス

  ----------------------------
  Date:    Jan 19 17:53:36 2013

  r904 avr output

  r903 dfi new

  ----------------------------
  Date:    Jan 15 19:09:08 2013

  r902 dfi output ok

  r901 revision up

  r900 dfi serial ok

  r899 working IOmode
   - リスタートのパラメータ指定を変更

  ----------------------------
  Date:    Jan 14 23:43:04 2013

  r898 working dfi

  r897 write check DFI

  r896 new dfi
   - DFIフォーマットの変更、新フォーマットに対応するまでplot3d出力は使えない
    (PLOT3Dディレクトリのソースを修正のこと)

  ----------------------------
  Date:    Jan 13 18:12:12 2013

  r895 working dfi

  r894 fileout is 1 step before

  r893 change IntervalManager class
   - ファイル出力タイミングの修正

  r892 date update

  r891 put velocity array of file back in place
   - ベクトルのファイル出力フォーマットを V(i,j,k,3) -> V(3,i,j,k)に戻す

  ----------------------------
  Date:    Dec 25 17:28:00 2012

  r890 outflow check ok

  ----------------------------
  Date:    Dec 24 21:37:27 2012

  r889 introduce w_w intot divergence()

  ----------------------------
  Date:    Dec 23 17:37:20 2012

  r888 working symmetric

  ----------------------------
  Date:    Dec 12 23:36:16 2012

  r887 vobc

  r886 modify wall condition

  ----------------------------
  Date:    Dec 11 00:00:58 2012

  r885 farfield

  ----------------------------
  Date:    Dec 10 19:51:14 2012

  r884 far field

  r883 outflow working

  r882 outflow ?

  ----------------------------
  Date:    Dec 9 23:56:19 2012

  r881 pvec_vobc_symmetric

  r880 step

  r879 modify comsph and layout util

  ----------------------------
  Date:    Dec 6 07:17:36 2012

  r878 working rm ref.vel

  ----------------------------
  Date:    Dec 5 19:05:49 2012

  r877 for RC seminar

  r876 sphere ocsilation

  ----------------------------
  Date:    Dec 4 16:17:23 2012

  r875 origin medium

  r874 ROUND_EPS

  ----------------------------
  Date:    Dec 1 18:16:07 2012

  r873 MediumTable ID COLOR

  r872 fix bid_fill and Polylib-2.2 & TextParser-1.2

  ----------------------------
  Date:    Nov 29 18:09:01 2012

  r871 working
   - OpenMPのDOループはSTATICに固定

  ----------------------------
  Date:    Nov 27 01:03:11 2012

  r870 heat

  ----------------------------
  Date:    Nov 21 14:42:49 2012

  r869 plot3d tp

  ----------------------------
  Date:    Nov 20 23:34:18 2012

  - Merge branch 'master' of ssh://hpcpf-dev.iis.u-tokyo.ac.jp/home/keno/cbc_git
    working both irigium and strontium

  r867 fix underscore

  ----------------------------
  Date:    Nov 19 19:11:23 2012

  r867 add ldc.tp

  ----------------------------
  Date:    Nov 17 15:39:45 2012

  r866 cell face velocity
   - セルフェイス速度d_vf

  r865 change delimiter of tp from _ to UpperLowerCase
   - パラメータをアンダースコア区切りから，大文字小文字区切りへ変更,
     ex.) Time_Control >> TimeControl

  ----------------------------
  Date:    Nov 16 21:43:00 2012

  r864 v(i,j,k,3) for PLOT3D
   - 速度を V(3,i,j,k) -> V(i,j,k,3)

  ----------------------------
  Date:    Nov 15 02:22:54 2012

  r863 change makefile
   - makeの方法を変更．コマンドラインでマクロを指定し，分岐
      $ make FFVC=intel     << intel
      $ make FFVC=gnu       << gnu
      $ make FFVC=fx        << FX10, K
      $ make FFVC=ibm       << IBM BG
     あるいは，makefileの先頭にマクロを定義する

  ----------------------------
  Date:    Nov 14 00:58:22 2012

  r862 make FFVCoption

  r861 omp do static

  ----------------------------
  Date:    Nov 13 22:30:28 2012

  r860 cavity result is agree with r858

  r859 make cahnge

  ----------------------------
  Date:    Nov 11 17:04:49 2012

  r858 PCG/BICGSTAB
   - 反復解法に PCG, PBiCGSTAB, RBGSを追加

  r857 CG

  r856 plot3d

  r855 plot3d library

  ----------------------------
  Date:    Nov 7 09:20:08 2012

  r854 university

  r853 PLOT3D

  r852 off PLOT3D

  ----------------------------
  Date:    Nov 6 00:57:50 2012

  r851 working

  ----------------------------
  Date:    Nov 4 22:33:55 2012

  r850 introduce libPLOT3D
   - PLOT3D関連ソースをPLOT3Dディレクトリに移動

  r849 tex update

  ----------------------------
  Date:    Oct 18 18:35:01 2012

  r848 restart staging option
   - リスタートパラメータの指定を変更．ステージングオプション
   - ビルドを一括で行う >> Polylib-2.1.2, CUtlib-2.0.5, PMlib-1.5, TextParser-1.1
   - ファイル出力のディレクトリ対応
   - 入力ファイルをひとつにする
   - plot3d関連修正

  r847 write HPCPF_EXIT_STATUS file

  r846 add HPCPF status

  ----------------------------
  Date:    Oct 16 08:37:26 2012

  r845 FFV088

  r844 modify make

  r843 PMli-1.5

  r842 PM1.5

  r841 modify r840 by haamguchi + make

  ----------------------------
  Date:    Oct 14 14:49:36 2012

  r840 modify r838 haamguchi

  r834 comment

  ----------------------------
  Date:    Oct 8 23:00:29 2012

  r838 FFV87/FB103

  r837 compsph/layout Makefile
   - Util_Combsph, Util_Layoutを追加

  r836 working

  r833 working

  r834 working

  ----------------------------
  Date:    Oct 7 00:27:44 2012

  r833 modify r831 by hamaguchi

  ----------------------------
  Date:    Oct 6 17:59:56 2012

  r832 under construction : r831 hamaguchi

  ----------------------------
  Date:    Oct 4 16:47:15 2012

  r831 ffvc-0.9.2

  r830 read3

  ----------------------------
  Date:    Oct 3 19:29:36 2012

  r829 add read3

  ----------------------------
  Date:    Oct 2 18:34:34 2012

  r828 lower limit itr=2

  r827 restart mem disp

  r826 gemini

  r825 example update

  r824 fix r0

  ----------------------------
  Date:    Oct 1 23:01:21 2012

  r823 uni file

  r822 time slice

  r821 out dir

  ----------------------------
  Date:    Sep 30 23:39:09 2012

  r820 c_mkdir()

  r819 new iteration process
           - 反復法のプロセスを変更
  r818 inside

  ----------------------------
  Date:    Sep 26 18:00:21 2012

  r817 ax=b

  r816 K-1

  ----------------------------
  Date:    Sep 25 19:49:57 2012

  r815 fgmres

  r814 unit conversion for array

  r813 arrayops

  r812 xcopy

  ----------------------------
  Date:    Sep 24 19:40:54 2012

  r811 iteration

  r810 working

  ----------------------------
  Date:    Sep 21 13:57:30 2012

  r809 working fgmres

  ----------------------------
  Date:    Sep 18 10:50:46 2012

  r808 fgmres

  r807 add algoritms

  r806 modify inside_ffvc

  ----------------------------
  Date:    Sep 16 01:53:21 2012

  r805 working

  ----------------------------
  Date:    Sep 15 16:26:47 2012

  r804 add doc

  ----------------------------
  Date:    Sep 14 22:12:02 2012

  r803 ffvc-0.9.1

  ----------------------------
  Date:    Sep 12 18:31:56 2012

  r802 itor

  r801 itor

  ----------------------------
  Date:    Sep 11 20:22:18 2012

  r800 gmres

  r799 add gmres pm

  r798 gmres para

  r797 gmres check

  r796 sleepy

  r795 gmres

  ----------------------------
  Date:    Sep 10 10:22:45 2012

  r794 still gmres

  r793 gmres...

  ----------------------------
  Date:    Sep 9 17:49:34 2012

  r792 gmres working

  r791 working

  ----------------------------
  Date:    Sep 8 19:06:23 2012

  r790 vinas src

  r789 add BG/P make setting

  r788 fix time ocntrol

  ----------------------------
  Date:    Sep 7 19:35:35 2012

  r787 working

  r786 ffv-0.9

  r785 Poly, PM update

  ----------------------------
  Date:    Sep 6 20:31:49 2012

  r784 PMlib-1.4

  r783 ffv-82 / fb-99

  r782 scaling postpone

  r781 polygon scaling working
   - ポリゴンのスケーリング機能 >> Hidden

  ----------------------------
  Date:    Sep 5 20:08:15 2012

  r780 history time out

  r779 change div method

  r778 pointset under way

  r777 package

  r776 HT_SN

  r775 change lbc format

  ----------------------------
  Date:    Sep 4 18:28:11 2012

  r774 LBC working

  r773 voxel output

  r772 vox out control

  r771 modify on K

  r770 package

  - FB-97/ffv-80

  ----------------------------
  Date:    Sep 3 20:17:17 2012

  r768 working

  r767 burner ok

  r766 working

  r765 clean

  r764 cds compiled

  r763 pscalar working

  ----------------------------
  Date:    Sep 2 22:57:59 2012

  r762 cds

  r761 vspec reverse

  r760 vspec

  r759 wk

  r758 fill omp

  r757 symmetric fill

  ----------------------------
  Date:    Sep 1 16:21:17 2012

  r756 solid-from-cut working

  r755 Polylib-2.1

  ----------------------------
  Date:    Aug 31 11:23:39 2012

  r754

  r753 specv working

  ----------------------------
  Date:    Aug 31 09:00:39 2012

  r752 wrk

  ----------------------------
  Date:    Aug 30 19:30:27 2012

  r751 fake

  r750 rm Polylib b+

  r746 local bc label

  r745 Polylib_f

  r747 init last

  ----------------------------
  Date:    Aug 29 06:58:21 2012

  r746 polylib b+

  ----------------------------
  Date:    Aug 27 11:32:02 2012

  r745 rm CPM105

  ----------------------------
  Date:    Aug 25 23:06:20 2012

  r744 CPMlib106
   - CPMlib-1.0.6対応

  r743 makefile

  ----------------------------
  Date:    Aug 23 21:00:20 2012

  r742 credit

  ----------------------------
  Date:    Aug 22 21:47:32 2012

  r741 restart fix

  r740 debug write off

  r739 copyright 2012

  r738 1step elapse

  r737 plot3d related fix

  r736 interval fix

  ----------------------------
  Date:    Aug 21 19:43:56 2012

  r735 fill check

  ----------------------------
  Date:    Aug 20 20:28:07 2012

  r734 IP cyl

  r733 add sphere

  r732 medium check

  r731 fix spacing issue

  ----------------------------
  Date:    Aug 19 22:00:50 2012

  r730 fix Hostonly issue

  r729 IP_Polygon ijk loop

  r728 try BG/P

  r727 ucd

  r726 fix spacing

  r725 dfi serial

  ----------------------------
  Date:    Aug 17 12:54:18 2012

  r724 dfi ok

  ----------------------------
  Date:    Aug 15 17:49:32 2012

  r723 dfi3

  r722 dfi2

  r721 dfi

  r720 dfi head/tail
   - dfi対応

  ----------------------------
  Date:    Aug 14 18:47:08 2012

  r719 change dfi to tp

  r718 intel compiler xe 2011

  ----------------------------
  Date:    Aug 13 17:59:09 2012

  r717 outflow issue?

  r716 fix IO_Gather bug

  r715 change order of func. in Control.C

  ----------------------------
  Date:    Aug 12 19:31:47 2012

  r714 change get*Index() to Macro

  r713 introduce fill hint

  r712 beautify VoxInfo

  r711 modify halo region to 6

  r710 rm textparser
   - textparser 1.1対応

  r709 rm libttfx

  r708 check

  ----------------------------
  Date:    Aug 10 13:48:48 2012

  r707 BndCommS4DEx() error

  ----------------------------
  Date:    Aug 8 09:36:57 2012

  r706 update 705 rev by vinas

  ----------------------------
  Date:    Aug 5 02:16:56 2012

  r705 double compile
   - 領域情報関連の浮動小数点変数はdoubleのインターフェイス

  ----------------------------
  Date:    Aug 4 23:43:03 2012

  r704 K modify

  r703 pmt.tp
   - domain.tpにlength_of_unitパラメータを導入

  r702 cpm105

  r701 fix statistics

  ----------------------------
  Date:    Aug 3 17:22:05 2012

  r700 medium on GC

  ----------------------------
  Date:    Aug 1 17:56:43 2012

  r699 replace allreduce int to ulong in Compo

  ----------------------------
  Date:    Jul 31 23:44:12 2012

  r698 fill

  ----------------------------
  Date:    Jul 30 16:35:16 2012

  r697 snapshot PM

  r696 update polylib
   - Polylib-2.1_Dev_b対応

  r695 openmp?

  r694 check cut

  ----------------------------
  Date:    Jul 29 19:20:00 2012

  r693 polylib working

  r692 polylib

  ----------------------------
  Date:    Jul 28 19:48:12 2012

  r691 modify r690 by hamaguchi

  ----------------------------
  Date:    Jul 23 16:10:49 2012

  r690 add PMlib1.3

  r689 FB92/FFV50

  r688 fix cutlib include

  r687 rm Polylib_203

  r686 modified r683 compiled

  r685 modify hamaguchi r683

  ----------------------------
  Date:    Jul 21 18:50:03 2012

  r684 working r683 plot3d
   - PLOT3Dフォーマット導入

  ----------------------------
  Date:    Jul 17 19:55:47 2012

  r683 p average

  r682 working

  ----------------------------
  Date:    Jul 16 18:39:30 2012

  r681 sma comm

  r680 sma?
   - SOR2SMAのCPMlib実装

  ----------------------------
  Date:    Jul 14 18:05:21 2012

  r679 modify voxel init

  r678 fix domainflux

  r677 fix sync bug

  r676 FB090/FFV040

  ----------------------------
  Date:    Jul 11 20:28:53 2012

  r675 PMlib 1.2

  r674 comm

  ----------------------------
  Date:    Jul 10 17:38:31 2012

  r673 sma comm

  r672 parseBC cmp

  r671 comm sor

  ----------------------------
  Date:    Jul 9 19:28:22 2012

  r670 rm class pointer

  r699 run

  r698 LS

  ----------------------------
  Date:    Jul 8 22:45:51 2012

  r697 sor2sma thinking

  r696 binary

  ----------------------------
  Date:    Jul 7 18:35:47 2012

  r695 NS_binary

  r694 timestamp

  r693 initilize

  r692 init compile

  ----------------------------
  Date:    Jul 6 19:01:59 2012

  r692 working

  ----------------------------
  Date:    Jul 5 19:58:17 2012

  r691 update CPMlib 103
   - データクラスをポインタへ置換

  ----------------------------
  Date:    Jul 3 23:37:28 2012

  r690 compiling

  r689 add ffv_Restart.C

  r688 initilize

  ----------------------------
  Date:    Jul 2 22:44:05 2012

  r687 restart

  r686 dfi

  r685 2d alloc

  r684 voxencode

  r683 INDEX

  ----------------------------
  Date:    Jul 1 11:05:31 2012

  r682 /day morning

  r681 indexing

  ----------------------------
  Date:    Jun 30 18:27:29 2012

  r680 CompoFraction

  r679 medium ok

  r678 ffv20/fb80

  r677 compiled

  r676 rename fortran routines
   - 関数名を再構築

  ----------------------------
  Date:    Jun 29 18:19:48 2012

  r675 allreduce error

  r674 add SetBC3D

  r673 working

  r672 rm IP_Users

  r671 rm IP::setControlVars

  r670 add polylib 2.1.0-dev-a

  r669 check 1

  r668 working

  ----------------------------
  Date:    Jun 28 20:02:56 2012

  r667 domaininfo

  r666 polylib 2.1.0 dev

  ----------------------------
  Date:    Jun 27 20:05:39 2012

  r665 working

  r664 change uint 2 int

  r663 vinfo int

  ----------------------------
  Date:    Jun 26 21:33:29 2012

  r662 shinkansen

  r661 working

  ----------------------------
  Date:    Jun 25 23:02:41 2012

  r660 working

  r659 load medium

  r658 laod aprameters

  ----------------------------
  Date:    Jun 24 23:14:40 2012

  r657 compiling...

  ----------------------------
  Date:    Jun 23 22:18:30 2012

  r656 compiling

  r655 working

  r654 move new Makefile

  r653 working make

  r652 change make

  r651 rm parallel_info.h

  r650 add bin

  ----------------------------
  Date:    Jun 22 19:33:54 2012

  r649 ffv class

  ----------------------------
  Date:    Jun 22 16:27:41 2012

  r648 run cpmlib

  r647 rm CPMlib

  r646 add cpm

  ----------------------------
  Date:    Jun 21 23:37:50 2012

  r645 working

  r644 outerbc alias

  ----------------------------
  Date:    Jun 20 14:00:15 2012

  r643 working

  ----------------------------
  Date:    Jun 18 19:46:04 2012

  r642 working

  r641 working

  ----------------------------
  Date:    Jun 16 18:52:36 2012

  r640 rm IDtable.h

  r639 rm textparser0.9

  r638 change initialize

  ----------------------------
  Date:    Jun 11 19:15:22 2012

  r637 IP

  r636 working

  ----------------------------
  Date:    Jun 7 20:21:45 2012

  r635 parser changing

  r634 compile ok

  r633 build cpmlib, tplib

  r632 add CPMlib in project_local_settings

  r631 build CPMlib

  ----------------------------
  Date:    Jun 6 23:53:44 2012

  r630 add CPMlib
   - CPMライブラリを用いて並列管理テスト

  r629 change TP in project_local_setting

  r628 add TP/include

  r627 add tp & TPControl class

  ----------------------------
  Date:    Jun 3 18:16:11 2012

  r626 caeru branch compile option

  r625 add FX/K compile option

  r624 modify min -> if

  ----------------------------
  Date:    Jun 2 18:56:10 2012

  r623 fix min_distance

  ----------------------------
  Date:    May 29 19:51:13 2012

  r622 cutinfo check

  r621 modify ulong

  r620 change ulong

  ----------------------------
  Date:    May 26 15:57:18 2012

  r619 gather has problem

  r618 sphere ok

  r617 u-nn

  ----------------------------
  Date:    May 25 17:23:25 2012

  r616 change scancell algorithm

  ----------------------------
  Date:    May 24 21:38:58 2012

  r615 int_array_allreduce

  r614 ghost mpi allreduce

  r613 change MPI-comm in Voxinfo

  r612 modify cbc_helicity & avr/rms

  ----------------------------
  Date:    May 23 21:07:24 2012

  r611 unsigned

  r610 char(dim)

  r609 add cbc_force

  r608 id_sph

  ----------------------------
  Date:    May 22 22:29:44 2012

  r607 PMT silent

  r606 modify write index

  r605 coarse restart ok

  ----------------------------
  Date:    May 21 17:56:18 2012

  r604 coarse git l5

  r603 166/260

  r602 coarse restart

  r601 still

  ----------------------------
  Date:    May 20 23:16:32 2012

  r600 coarse problem

  r598 still restart problem

  r598 restart

  r597 dfi bug aruyo

  ----------------------------
  Date:    May 19 22:05:24 2012

  r596 add FB/dfi

  r595 mv dfi to FB

  r594 dfi working

  r593 dfi vsph free

  r592 dfi class

  r591 rm Control_Rect

  ----------------------------
  Date:    May 18 20:07:18 2012

  r590 dfi working

  ----------------------------
  Date:    May 17 15:00:28 2012

  r589 add dfi func

  ----------------------------
  Date:    May 16 15:20:55 2012

  r588 modify dfi load

  r587 rough restart serial ok

  r586 rough working

  ----------------------------
  Date:    May 15 20:02:40 2012

  r585 working

  r584 restart change

  r583 working

  ----------------------------
  Date:    May 14 20:03:54 2012

  r582 change file io on the way

  r581 seg fault

  ----------------------------
  Date:    May 12 08:26:59 2012

  r580 check_fill is modified to mpi

  ----------------------------
  Date:    May 11 15:57:32 2012

  r579 modify 1/h

  ----------------------------
  Date:    May 10 20:05:05 2012

  r578 working

  r577 fill mpi parallel ok

  ----------------------------
  Date:    May 9 22:53:11 2012

  r576 cal. force

  ----------------------------
  Date:    May 8 14:12:57 2012

  r575 cds upwinding neighboring to solid

  ----------------------------
  Date:    May 7 22:38:22 2012

  r574 rough interpolation ok

  r573 rough check

  r572 rough load

  r571 test SZ

  ----------------------------
  Date:    May 6 23:56:29 2012

  r570 move doc

  r569 rough interpolation

  ----------------------------
  Date:    May 4 16:57:15 2012

  r568 filled

  ----------------------------
  Date:    May 2 19:59:52 2012

  r567 fill cut

  r566 update PMlib doc

  ----------------------------
  Date:    May 1 19:23:48 2012

  r565 fill....

  r564 till working fill

  ----------------------------
  Date:    Apr 29 22:47:19 2012

  r563 working fill

  ----------------------------
  Date:    Apr 28 19:04:28 2012

  r562 working fill

  r561 PMlib manual

  r560 independent PMlib

  ----------------------------
  Date:    Apr 27 00:57:25 2012

  r559 alternate c++ omp ruduction min

  ----------------------------
  Date:    Apr 24 07:26:18 2012

  r558 working fill

  ----------------------------
  Date:    Apr 22 10:58:44 2012

  r557 Polylib/Cutlib 2.0.3

  ----------------------------
  Date:    Apr 21 23:07:30 2012

  r556 modify viscous term

  r555 check

  ----------------------------
  Date:    Apr 20 20:18:42 2012

  r554 cut-binary

  r553 BCvec bug fix

  r552 modify intrinsic class treatment

  ----------------------------
  Date:    Apr 19 18:54:39 2012

  r551 K cimpiler option & fb_util.f90

  ----------------------------
  Date:    Apr 18 18:04:47 2012

  r550 modify buffer

  r549 fapp

  r548 pre release 150

  ----------------------------
  Date:    Apr 15 16:39:08 2012

  r547 fix getFindex3Dex in Sampling.h

  r546 unit ocnversion

  r545 fix average

  r544 itor test

  r543 debug func

  r542 stil working itor

  ----------------------------
  Date:    Apr 14 18:39:10 2012

  r541 bug! itor

  ----------------------------
  Date:    Apr 13 10:12:52 2012

  r540 fix para_mode

  ----------------------------
  Date:    Apr 12 23:28:20 2012

  r539 add parallel mode to PM class

  r538 pressure shift

  r537 BCvec_cc openMP

  ----------------------------
  Date:    Apr 9 19:02:34 2012

  r536 neumann BC

  ----------------------------
  Date:    Apr 8 23:04:30 2012

  r535 tfree for fluid face

  r534 tfree bug

  ----------------------------
  Date:    Apr 7 18:57:11 2012

  r533 working cds

  r532 change torelance of cut

  ----------------------------
  Date:    Apr 1 17:55:45 2012

  r531 div?

  r530 take cut effect into velocity at cell face

  r529 intro CompoList::bc_dir

  ----------------------------
  Date:    Mar 31 17:40:43 2012

  r528 working vspec

  r527 add func to Polylib

  ----------------------------
  Date:    Mar 30 16:16:42 2012

  r526 encVbit_IBC_Cut() working

  r525 CDS vspec

  ----------------------------
  Date:    Mar 29 16:56:25 2012

  r524 working

  r523 singleton

  ----------------------------
  Date:    Mar 28 23:58:25 2012

  r522 some classes are merged in Control

  ----------------------------
  Date:    Mar 27 19:22:29 2012

  r521 singleton parseMat

  r520 singleton Control class

  ----------------------------
  Date:    Mar 25 18:22:55 2012

  r519 stil step issue

  ----------------------------
  Date:    Mar 25 09:18:07 2012

  r517 check

  ----------------------------
  Date:    Mar 24 18:58:01 2012

  r516 sphere ok?

  ----------------------------
  Date:    Mar 22 18:52:02 2012

  r515 cut

  ----------------------------
  Date:    Mar 21 23:37:05 2012

  r514 modify parabolic solution

  r513 working

  r512 introduce IP_Sphere

  ----------------------------
  Date:    Mar 20 16:43:37 2012

  r511 cds_vector

  r510 cds working

  ----------------------------
  Date:    Mar 18 18:03:33 2012

  r509 cds working

  - done component array

  r507 working component array

  ----------------------------
  Date:    Mar 17 18:25:31 2012

  r506 introducing component array

  r505 forcing...

  ----------------------------
  Date:    Mar 16 18:17:24 2012

  r504 forcing modify

  ----------------------------
  Date:    Mar 15 19:40:23 2012

  r503 forcing

  r502 add tm_prj_vec_bc_comm

  - openmp static

  ----------------------------
  Date:    Mar 11 17:13:34 2012

  r500 omp pokayoke

  r499 omp

  ----------------------------
  Date:    Mar 7 17:52:01 2012

  r498 omp static test

  r497 rm omp*.h

  ----------------------------
  Date:    Mar 6 19:45:10 2012

  - introduce omp_head/tail

  ----------------------------
  Date:    Mar 3 18:10:19 2012

  - add unused.f90

  r494 reduce index function

  r493 complete component VF

  r492 under construction

  ----------------------------
  Date:    Mar 2 18:19:37 2012

  r491 compo rad/fan modify

  ----------------------------
  Date:    Mar 1 17:27:10 2012

  r490 shape min/max

  ----------------------------
  Date:    Feb 29 14:01:31 2012

  r489 IBC outflow requires nv

  ----------------------------
  Date:    Feb 28 19:21:33 2012

  r484 Hex Parser

  r483 CompoFraction OK

  ----------------------------
  Date:    Feb 27 21:35:59 2012

  r482 rotate + translation

  r481 try & error geometry

  ----------------------------
  Date:    Feb 26 22:46:34 2012

  r480 modify judgeCylider()

  - add center in CompoFraction class

  ----------------------------
  Date:    Feb 24 19:43:08 2012

  - assert(0) >> Exit(0)

  ----------------------------
  Date:    Feb 22 18:13:45 2012

  r476 remove Skl.h from FB class

  r457 change SKL_REAL to REAL_TYPE

  r474 move shiftVin/out to FileIO class

  r473 component VF implementation

  ----------------------------
  Date:    Feb 20 18:58:06 2012

  r472 add CompoFraction class

  r471 flop counting update

  ----------------------------
  Date:    Feb 16 09:59:17 2012

  r470 remove Core_Util class -> fb_util.f90 and FBUtility class

  ----------------------------
  Date:    Feb 15 19:03:43 2012

  r469 cbc_util

  r468 fb_util

  r467 mv cbc_f_params.h

  ----------------------------
  Date:    Feb 14 18:06:17 2012

  r466 add false to tm_statistic

  - Merge branch '3DEx'

  - Conflicts:
   - src/PRJ_CBC/CBC/SklSolverCBC.C

  r464 SklVector3D to SklVector3DEx

  r463 add tm_statistic

  ----------------------------
  Date:    Feb 13 11:45:17 2012

  - replace constant u_bc_ref2 in cbc_pvec_vobc_wall

  r461 enhance muscl by replacing constant

  r460 change counting cbc_ee, vobc_wall, muscl

  ----------------------------
  Date:    Feb 12 17:38:01 2012

  r459 replace version 151-247 of PMT

  - add empty directory

  - recount flop based on PA info on K

  ----------------------------
  Date:    Feb 9 22:47:36 2012

  r456 re-count flops

  ----------------------------
  Date:    Feb 8 17:57:40 2012

  r455 add pm_3840.xml

  - Merge branch 'master' of ssh://hpcpf-dev.iis.u-tokyo.ac.jp/home/keno/cbc_git

  - change label cbc_norm_v_div_max

  ----------------------------
  Date:    Feb 3 19:30:39 2012

  r453 change remark of cbc_norm_vmax_div

  ----------------------------
  Date:    Feb 2 22:15:04 2012

  r452

  ----------------------------
  Date:    Feb 1 15:07:28 2012

  r451 change
