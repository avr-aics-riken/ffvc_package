CDMlib
======

Cartesian Data Management library, a former CIOlib. New features are incorporated in CDMlib such as plot3d file format, and non-uniform Cartesian data.
