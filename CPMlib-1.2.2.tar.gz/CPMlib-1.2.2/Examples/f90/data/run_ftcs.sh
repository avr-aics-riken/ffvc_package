#!/bin/sh

  mpirun -np 8 ../mconvp_CPM < in.ftcs

