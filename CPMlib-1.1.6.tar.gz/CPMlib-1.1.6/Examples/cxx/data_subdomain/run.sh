#!/bin/sh

  mpirun -np 22 ../exampleCXX input.txt

