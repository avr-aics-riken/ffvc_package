#!/bin/sh

  mpirun -np 24 ../exampleCXX input1.txt input2.txt

