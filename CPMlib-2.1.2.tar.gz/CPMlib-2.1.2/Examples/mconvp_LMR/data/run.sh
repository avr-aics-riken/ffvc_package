#!/bin/sh

  mpirun -np 15 ../mconvp_LMR mconv.tp

