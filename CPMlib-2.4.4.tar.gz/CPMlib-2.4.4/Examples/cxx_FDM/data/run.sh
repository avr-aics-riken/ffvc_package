#!/bin/sh

  mpirun -np 24 ../exampleCXX_FDM input1.txt input2.txt

