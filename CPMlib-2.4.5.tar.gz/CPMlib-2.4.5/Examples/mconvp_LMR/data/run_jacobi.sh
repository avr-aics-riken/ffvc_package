#!/bin/sh

  mpirun -np 4 ../mconvp_LMR mconv_jacobi.tp

