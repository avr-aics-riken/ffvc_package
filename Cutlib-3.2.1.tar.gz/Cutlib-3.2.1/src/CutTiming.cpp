/// @file
/// @brief 時間測定用クラス 実装
///

#include "CutTiming.h"

namespace cutlib {

/// 時間測定ストップウオッチリスト.
Timer Timer::Timers[NumSections];

} // namespace cutlib

