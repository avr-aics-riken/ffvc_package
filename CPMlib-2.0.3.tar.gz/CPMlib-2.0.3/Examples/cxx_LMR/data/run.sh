#!/bin/sh

  mpirun -np 15 ../exampleCXX_LMR leaf15.tp #leaf15.tp

