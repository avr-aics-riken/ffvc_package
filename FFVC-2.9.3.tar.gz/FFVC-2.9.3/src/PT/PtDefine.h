#ifndef _PT_DEFINE_H_
#define _PT_DEFINE_H_

//##################################################################################
//
// Copyright (c) 2019 Research Institute for Information Technology, Kyushu university
// All rights researved.
//
//##################################################################################


#define NDST 27 // 送受信数は26だが、マップと合わせている

#define BUF_UNIT 10000  // バッファ初期値と更新サイズ

// #define PT_DEBUG ON

#define PT_TIMING__ if (1)

#endif // _PT_DEFINE_H_
